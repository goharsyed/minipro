import React from 'react';
import TransportCommon from "./TransportCommon";

const BusRequest = () => {
    return (
        <>
          <TransportCommon name="BUS"/>
        </>
    )
}

export default BusRequest