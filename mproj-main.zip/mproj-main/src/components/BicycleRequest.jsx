
import TransportCommon from './TransportCommon'
const BicycleRequest = () => {
 
  return (
    <>
    <TransportCommon name="BICYCLE" />
    </>
  );
};

export default BicycleRequest;

