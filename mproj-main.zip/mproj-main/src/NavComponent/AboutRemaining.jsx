import React from "react";

const AboutRemaining = () => {
  return (
    <>
      <div className="for_margin col-sm-8 col-md-6 mt-5 mx-auto ">
        <h1 className="text-center m-5 ">THE MISSION</h1>
        <p className="text-center font_adjust">
          ipsum dolor sit amet consectetur adipisicing elit. Voluptatem,
          molestiae tempore voluptate quis repellendus architecto eius
          voluptates nulla veritatis eveniet tempora libero nisi, veniam
          perferendis accusantium est in illo pariatur.
        </p>
      </div>
      
    </>
  );
};

export default AboutRemaining;
