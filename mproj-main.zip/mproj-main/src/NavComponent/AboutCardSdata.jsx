import wb1 from './images/sharukh.jpg'
const AboutCardSdata=[
    {
        imgsrc: wb1,
        title:"SURAJ KUMAR"
    },
    {
        imgsrc: wb1,
        title:"SERAJ AHAMAD"
    },
    {
        imgsrc: wb1,
        title:"SHARTHAK SINHA"
    },
    {
        imgsrc: wb1,
        title:"SHASHI BHUSHAN"
    },
];
export default AboutCardSdata;